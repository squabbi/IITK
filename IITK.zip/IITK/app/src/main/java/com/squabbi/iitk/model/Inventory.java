package com.squabbi.iitk.model;

import java.util.List;

public class Inventory {
    private String mName;
    private List<Item> mInventoryList;
}
